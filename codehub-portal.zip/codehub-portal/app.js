// Main Application
class CodeHubApp {
    constructor() {
        this.currentUser = null;
        this.currentRoom = 'web-dev';
        this.currentTab = 'dashboard';
        this.editingProjectId = null;
        this.editingMessageId = null; // For editing messages
        this.initializeApp();
    }

    initializeApp() {
        console.log('🚀 Initializing CodeHub App...');
        
        // Check if user is logged in
        this.checkAuthStatus();
        
        // Setup event listeners
        this.setupEventListeners();
        
        // Setup routing
        this.setupRouting();
        
        // Load default data
        this.loadDefaultData();
        
        console.log('✅ App initialized successfully');
    }

    checkAuthStatus() {
        const userData = localStorage.getItem('codehub_user');
        if (userData) {
            try {
                this.currentUser = JSON.parse(userData);
                this.updateAuthUI();
            } catch (error) {
                console.error('Error parsing user data:', error);
                localStorage.removeItem('codehub_user');
            }
        }
        
        // Add default user if none exists
        this.initializeDefaultUsers();
    }

    initializeDefaultUsers() {
        const defaultUsers = [
            {
                id: 1,
                username: 'demo',
                email: 'demo@codehub.dev',
                password: 'demo123',
                mobile: '',
                skills: ['JavaScript', 'HTML', 'CSS', 'React'],
                solvedProblems: 5,
                contributions: 3,
                createdAt: new Date().toISOString()
            }
        ];
        
        // Store in localStorage if not exists
        if (!localStorage.getItem('codehub_users')) {
            localStorage.setItem('codehub_users', JSON.stringify(defaultUsers));
        }
    }

    updateAuthUI() {
        const authButtons = document.getElementById('authButtons');
        const navMenu = document.getElementById('navMenu');
        
        if (this.currentUser) {
            // User is logged in
            authButtons.innerHTML = `
                <span class="user-greeting">Hi, ${this.currentUser.username}</span>
                <button class="btn btn-outline" id="logoutBtn">Logout</button>
            `;
            
            // Enable all navigation links
            navMenu.innerHTML = `
                <a href="#home" class="nav-link">Home</a>
                <a href="#dashboard" class="nav-link active">Dashboard</a>
                <a href="#projects" class="nav-link">Projects</a>
                <a href="#chat" class="nav-link">Chat</a>
                <a href="#profile" class="nav-link">Profile</a>
            `;
            
            // Add logout event
            document.getElementById('logoutBtn').addEventListener('click', () => {
                this.logout();
            });
        } else {
            // User is not logged in
            authButtons.innerHTML = `
                <button class="btn btn-outline" id="loginBtn">Login</button>
                <button class="btn btn-primary" id="signupBtn">Sign Up</button>
            `;
            
            // Update navigation
            navMenu.innerHTML = `
                <a href="#home" class="nav-link active">Home</a>
                <a href="#dashboard" class="nav-link">Dashboard</a>
                <a href="#projects" class="nav-link">Projects</a>
                <a href="#chat" class="nav-link">Chat</a>
                <a href="#profile" class="nav-link">Profile</a>
            `;
        }
    }

    setupEventListeners() {
        // Mobile menu toggle
        document.getElementById('navToggle').addEventListener('click', () => {
            document.getElementById('navMenu').classList.toggle('active');
        });

        // Auth buttons (event delegation)
        document.addEventListener('click', (e) => {
            if (e.target.id === 'loginBtn' || e.target.closest('#loginBtn')) {
                this.showPage('loginPage');
            }
            if (e.target.id === 'signupBtn' || e.target.closest('#signupBtn')) {
                this.showPage('signupPage');
            }
        });

        // Home page buttons
        document.getElementById('getStarted')?.addEventListener('click', () => {
            this.showPage('signupPage');
        });

        document.getElementById('exploreProjects')?.addEventListener('click', () => {
            if (this.currentUser) {
                this.showPage('dashboardPage');
                this.switchTab('projects');
            } else {
                this.showPage('loginPage');
            }
        });

        document.getElementById('ctaSignup')?.addEventListener('click', () => {
            this.showPage('signupPage');
        });

        // Login form
        document.getElementById('loginForm')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleLogin();
        });

        // Signup form
        document.getElementById('signupForm')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleSignup();
        });

        // Password toggle
        document.getElementById('toggleLoginPassword')?.addEventListener('click', () => {
            this.togglePassword('loginPassword', 'toggleLoginPassword');
        });

        document.getElementById('toggleSignupPassword')?.addEventListener('click', () => {
            this.togglePassword('signupPassword', 'toggleSignupPassword');
        });

        // Dashboard tabs
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tab = e.target.dataset.tab;
                this.switchTab(tab);
            });
        });

        // Chat room buttons
        document.querySelectorAll('.room-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const room = e.target.dataset.room;
                this.switchRoom(room);
            });
        });

        // Send message
        document.getElementById('sendMessage')?.addEventListener('click', () => {
            this.sendMessage();
        });

        // Add project button
        document.getElementById('addProjectBtn')?.addEventListener('click', () => {
            this.showProjectModal();
        });

        // Project modal
        document.getElementById('closeModal')?.addEventListener('click', () => {
            this.hideModal('projectModal');
        });

        document.getElementById('cancelProject')?.addEventListener('click', () => {
            this.hideModal('projectModal');
        });

        document.getElementById('projectForm')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveProject();
        });

        // Add skill button
        document.getElementById('addSkillBtn')?.addEventListener('click', () => {
            this.addSkill();
        });

        // Press Enter to send message (with Shift for new line)
        document.getElementById('messageInput')?.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
    }

    setupRouting() {
        // Handle hash changes
        window.addEventListener('hashchange', () => {
            this.handleRoute();
        });

        // Initial route
        this.handleRoute();
    }

    handleRoute() {
        const hash = window.location.hash.substring(1) || 'home';
        let pageId;

        switch(hash) {
            case 'home':
                pageId = 'homePage';
                break;
            case 'login':
                pageId = 'loginPage';
                break;
            case 'signup':
                pageId = 'signupPage';
                break;
            case 'dashboard':
                pageId = 'dashboardPage';
                if (!this.currentUser) {
                    this.showPage('loginPage');
                    return;
                }
                break;
            case 'projects':
                pageId = 'dashboardPage';
                if (!this.currentUser) {
                    this.showPage('loginPage');
                    return;
                }
                this.switchTab('projects');
                break;
            case 'chat':
                pageId = 'dashboardPage';
                if (!this.currentUser) {
                    this.showPage('loginPage');
                    return;
                }
                this.switchTab('chatbox');
                break;
            case 'profile':
                pageId = 'profilePage';
                if (!this.currentUser) {
                    this.showPage('loginPage');
                    return;
                }
                break;
            default:
                pageId = 'homePage';
        }

        this.showPage(pageId);
        
        // Update navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${hash}`) {
                link.classList.add('active');
            }
        });
    }

    showPage(pageId) {
        // Hide all pages
        document.querySelectorAll('.page').forEach(page => {
            page.classList.remove('active');
        });

        // Show target page
        const targetPage = document.getElementById(pageId);
        if (targetPage) {
            targetPage.classList.add('active');
        }

        // Load page-specific data
        switch(pageId) {
            case 'dashboardPage':
                if (this.currentUser) {
                    this.loadDashboardData();
                }
                break;
            case 'profilePage':
                if (this.currentUser) {
                    this.loadProfileData();
                }
                break;
        }

        // Close mobile menu
        document.getElementById('navMenu')?.classList.remove('active');
    }

    async handleLogin() {
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        const messageEl = document.getElementById('loginMessage');

        if (!email || !password) {
            this.showMessage(messageEl, 'Please fill in all fields', 'error');
            return;
        }

        try {
            // Get users from localStorage
            const users = JSON.parse(localStorage.getItem('codehub_users') || '[]');
            const user = users.find(u => u.email === email && u.password === password);

            if (user) {
                // Remove password before storing
                const { password: _, ...userWithoutPassword } = user;
                this.currentUser = userWithoutPassword;
                
                // Save to localStorage
                localStorage.setItem('codehub_user', JSON.stringify(this.currentUser));
                
                // Show success message
                this.showMessage(messageEl, 'Login successful! Redirecting...', 'success');
                
                // Update UI
                this.updateAuthUI();
                
                // Add activity
                this.addActivity('Logged in', 'login');
                
                // Redirect to dashboard
                setTimeout(() => {
                    this.showPage('dashboardPage');
                }, 1000);
            } else {
                this.showMessage(messageEl, 'Invalid email or password', 'error');
            }
        } catch (error) {
            console.error('Login error:', error);
            this.showMessage(messageEl, 'An error occurred. Please try again.', 'error');
        }
    }

    async handleSignup() {
        const username = document.getElementById('signupUsername').value;
        const email = document.getElementById('signupEmail').value;
        const mobile = document.getElementById('signupMobile').value || '';
        const password = document.getElementById('signupPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        const messageEl = document.getElementById('signupMessage');

        // Validation
        if (!username || !email || !password || !confirmPassword) {
            this.showMessage(messageEl, 'Please fill in all required fields', 'error');
            return;
        }

        if (password !== confirmPassword) {
            this.showMessage(messageEl, 'Passwords do not match', 'error');
            return;
        }

        if (password.length < 6) {
            this.showMessage(messageEl, 'Password must be at least 6 characters', 'error');
            return;
        }

        if (!this.validateEmail(email)) {
            this.showMessage(messageEl, 'Please enter a valid email address', 'error');
            return;
        }

        try {
            // Get existing users
            const users = JSON.parse(localStorage.getItem('codehub_users') || '[]');
            
            // Check if user already exists
            if (users.some(u => u.email === email)) {
                this.showMessage(messageEl, 'Email already registered', 'error');
                return;
            }

            if (users.some(u => u.username === username)) {
                this.showMessage(messageEl, 'Username already taken', 'error');
                return;
            }

            // Create new user
            const newUser = {
                id: Date.now(),
                username,
                email,
                mobile,
                password,
                skills: [],
                solvedProblems: 0,
                contributions: 0,
                createdAt: new Date().toISOString()
            };

            // Save to users list
            users.push(newUser);
            localStorage.setItem('codehub_users', JSON.stringify(users));
            
            // Remove password and set as current user
            const { password: _, ...userWithoutPassword } = newUser;
            this.currentUser = userWithoutPassword;
            localStorage.setItem('codehub_user', JSON.stringify(this.currentUser));
            
            // Show success message
            this.showMessage(messageEl, 'Account created successfully! Redirecting...', 'success');
            
            // Update UI
            this.updateAuthUI();
            
            // Add activity
            this.addActivity('Created new account', 'signup');
            
            // Redirect to dashboard
            setTimeout(() => {
                this.showPage('dashboardPage');
            }, 1500);

        } catch (error) {
            console.error('Signup error:', error);
            this.showMessage(messageEl, 'An error occurred. Please try again.', 'error');
        }
    }

    logout() {
        this.currentUser = null;
        localStorage.removeItem('codehub_user');
        this.updateAuthUI();
        this.showPage('homePage');
        this.showToast('Logged out successfully', 'success');
    }

    loadDefaultData() {
        // Initialize default projects if none exist
        if (!localStorage.getItem('codehub_projects')) {
            const defaultProjects = [
                {
                    id: 1,
                    userId: 1,
                    title: 'Todo List App',
                    description: 'A simple todo list application with local storage',
                    techStack: ['HTML', 'CSS', 'JavaScript'],
                    difficulty: 'beginner',
                    githubUrl: 'https://github.com/example/todo-app',
                    liveUrl: 'https://example.com/todo-app',
                    createdAt: new Date().toISOString()
                },
                {
                    id: 2,
                    userId: 1,
                    title: 'Weather Dashboard',
                    description: 'Weather application using OpenWeather API',
                    techStack: ['React', 'JavaScript', 'CSS'],
                    difficulty: 'intermediate',
                    githubUrl: 'https://github.com/example/weather-app',
                    liveUrl: 'https://example.com/weather-app',
                    createdAt: new Date().toISOString()
                }
            ];
            localStorage.setItem('codehub_projects', JSON.stringify(defaultProjects));
        }

        // Initialize default messages if none exist
        if (!localStorage.getItem('codehub_messages')) {
            const defaultMessages = [
                {
                    id: 1,
                    userId: 1,
                    username: 'demo',
                    room: 'web-dev',
                    content: 'Welcome to the Web Development chat! Feel free to ask questions.',
                    timestamp: new Date().toISOString()
                },
                {
                    id: 2,
                    userId: 1,
                    username: 'demo',
                    room: 'web-dev',
                    content: 'Has anyone tried the new React features?',
                    timestamp: new Date(Date.now() - 3600000).toISOString() // 1 hour ago
                }
            ];
            localStorage.setItem('codehub_messages', JSON.stringify(defaultMessages));
        }

        // Initialize default activities if none exist
        if (!localStorage.getItem('codehub_activities')) {
            const defaultActivities = [
                {
                    id: 1,
                    userId: 1,
                    description: 'Joined CodeHub',
                    type: 'signup',
                    timestamp: new Date().toISOString()
                },
                {
                    id: 2,
                    userId: 1,
                    description: 'Created project: Todo List App',
                    type: 'project',
                    timestamp: new Date().toISOString()
                }
            ];
            localStorage.setItem('codehub_activities', JSON.stringify(defaultActivities));
        }
    }

    loadDashboardData() {
        if (!this.currentUser) return;

        // Load stats
        const projects = JSON.parse(localStorage.getItem('codehub_projects') || '[]');
        const messages = JSON.parse(localStorage.getItem('codehub_messages') || '[]');
        const activities = JSON.parse(localStorage.getItem('codehub_activities') || '[]');

        // Filter user-specific data
        const userProjects = projects.filter(p => p.userId === this.currentUser.id);
        const userMessages = messages.filter(m => m.userId === this.currentUser.id);
        const userActivities = activities.filter(a => a.userId === this.currentUser.id);

        // Update stats
        document.getElementById('projectCount').textContent = userProjects.length;
        document.getElementById('messageCount').textContent = userMessages.length;
        document.getElementById('solvedCount').textContent = this.currentUser.solvedProblems || 0;
        document.getElementById('contributionCount').textContent = this.currentUser.contributions || 0;
        document.getElementById('userGreeting').textContent = this.currentUser.username;

        // Load activity list
        this.loadActivityList(userActivities);
    }

    loadActivityList(activities) {
        const container = document.getElementById('activityList');
        container.innerHTML = '';

        if (activities.length === 0) {
            container.innerHTML = '<p class="text-center">No recent activity</p>';
            return;
        }

        // Sort by timestamp (newest first) and take latest 5
        const recentActivities = activities
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
            .slice(0, 5);

        recentActivities.forEach(activity => {
            const item = document.createElement('div');
            item.className = 'activity-item';
            item.innerHTML = `
                <div class="activity-icon">
                    <i class="fas fa-${this.getActivityIcon(activity.type)}"></i>
                </div>
                <div class="activity-content">
                    <p>${activity.description}</p>
                    <small>${new Date(activity.timestamp).toLocaleString()}</small>
                </div>
            `;
            container.appendChild(item);
        });
    }

    switchTab(tab) {
        this.currentTab = tab;
        
        // Update tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.tab === tab) {
                btn.classList.add('active');
            }
        });

        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
            if (content.id === `${tab}Tab`) {
                content.classList.add('active');
                
                // Load tab-specific data
                if (tab === 'projects') {
                    this.loadProjects();
                } else if (tab === 'chatbox') {
                    this.loadChatMessages();
                }
            }
        });
    }

    switchRoom(room) {
        this.currentRoom = room;
        
        // Update room buttons
        document.querySelectorAll('.room-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.room === room) {
                btn.classList.add('active');
            }
        });

        // Update room title
        const roomTitles = {
            'web-dev': 'Web Development',
            'data-analytics': 'Data Analytics',
            'dsa': 'Data Structures & Algorithms',
            'debugging': 'Debugging Help',
            'startup': 'Startup Ideas'
        };
        
        document.getElementById('currentRoom').textContent = roomTitles[room] || room;
        
        // Reset editing message
        this.cancelMessageEdit();
        
        // Load messages for the room
        this.loadChatMessages();
    }

    loadChatMessages() {
        const container = document.getElementById('chatMessages');
        container.innerHTML = '';

        const messages = JSON.parse(localStorage.getItem('codehub_messages') || '[]');
        const roomMessages = messages
            .filter(m => m.room === this.currentRoom)
            .sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

        if (roomMessages.length === 0) {
            container.innerHTML = `
                <div class="text-center">
                    <p>No messages yet. Start the conversation!</p>
                </div>
            `;
            return;
        }

        roomMessages.forEach(message => {
            const messageElement = this.createMessageElement(message);
            container.appendChild(messageElement);
        });

        // Scroll to bottom
        container.scrollTop = container.scrollHeight;

        // Update online users (simulated)
        const onlineUsers = new Set(roomMessages.map(m => m.userId));
        document.getElementById('onlineUsers').textContent = onlineUsers.size;
    }

    createMessageElement(message) {
        const isOwn = message.userId === this.currentUser.id;
        const time = new Date(message.timestamp).toLocaleTimeString([], { 
            hour: '2-digit', 
            minute: '2-digit' 
        });

        const messageDiv = document.createElement('div');
        messageDiv.className = `message-bubble ${isOwn ? 'own' : ''}`;
        messageDiv.dataset.id = message.id;
        
        let actionsHtml = '';
        if (isOwn) {
            actionsHtml = `
                <div class="message-actions">
                    <button class="btn btn-small edit-message" data-id="${message.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-small delete-message" data-id="${message.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
        }

        messageDiv.innerHTML = `
            <div class="message-header">
                <span class="message-user">${message.username}</span>
                <span class="message-time">${time}</span>
            </div>
            <div class="message-content">${message.content}</div>
            ${actionsHtml}
        `;

        // Add event listeners for edit/delete buttons
        if (isOwn) {
            const editBtn = messageDiv.querySelector('.edit-message');
            const deleteBtn = messageDiv.querySelector('.delete-message');
            
            editBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.editMessage(message.id);
            });
            
            deleteBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.deleteMessage(message.id);
            });
        }

        return messageDiv;
    }

    sendMessage() {
        if (!this.currentUser) {
            this.showPage('loginPage');
            return;
        }

        const input = document.getElementById('messageInput');
        const content = input.value.trim();
        const sendBtn = document.getElementById('sendMessage');

        if (!content) return;

        try {
            const messages = JSON.parse(localStorage.getItem('codehub_messages') || '[]');
            
            if (this.editingMessageId) {
                // Edit existing message
                const messageIndex = messages.findIndex(m => m.id === this.editingMessageId);
                if (messageIndex !== -1 && messages[messageIndex].userId === this.currentUser.id) {
                    messages[messageIndex].content = content;
                    messages[messageIndex].updatedAt = new Date().toISOString();
                    localStorage.setItem('codehub_messages', JSON.stringify(messages));
                    
                    // Add activity
                    this.addActivity('Edited a message', 'message');
                    
                    this.showToast('Message updated successfully', 'success');
                    
                    // Reset edit mode
                    this.cancelMessageEdit();
                }
            } else {
                // Add new message
                const message = {
                    id: Date.now(),
                    userId: this.currentUser.id,
                    username: this.currentUser.username,
                    room: this.currentRoom,
                    content: content,
                    timestamp: new Date().toISOString()
                };

                messages.push(message);
                localStorage.setItem('codehub_messages', JSON.stringify(messages));

                // Add activity
                this.addActivity(`Sent a message in ${this.currentRoom}`, 'message');
            }

            // Clear input
            input.value = '';
            
            // Reload messages
            this.loadChatMessages();
            this.loadDashboardData();

        } catch (error) {
            console.error('Error sending message:', error);
            this.showToast('Failed to send message', 'error');
        }
    }

    editMessage(messageId) {
        const messages = JSON.parse(localStorage.getItem('codehub_messages') || '[]');
        const message = messages.find(m => m.id === messageId && m.userId === this.currentUser.id);
        
        if (message) {
            this.editingMessageId = messageId;
            document.getElementById('messageInput').value = message.content;
            document.getElementById('messageInput').focus();
            
            // Change button text
            document.getElementById('sendMessage').innerHTML = '<i class="fas fa-save"></i> Update';
            
            // Add cancel button if not exists
            if (!document.getElementById('cancelEditBtn')) {
                const chatActions = document.querySelector('.chat-actions');
                const cancelBtn = document.createElement('button');
                cancelBtn.id = 'cancelEditBtn';
                cancelBtn.className = 'btn btn-outline';
                cancelBtn.innerHTML = '<i class="fas fa-times"></i> Cancel';
                cancelBtn.addEventListener('click', () => {
                    this.cancelMessageEdit();
                });
                chatActions.appendChild(cancelBtn);
            }
        }
    }

    cancelMessageEdit() {
        this.editingMessageId = null;
        document.getElementById('messageInput').value = '';
        document.getElementById('sendMessage').innerHTML = '<i class="fas fa-paper-plane"></i> Send';
        
        // Remove cancel button
        const cancelBtn = document.getElementById('cancelEditBtn');
        if (cancelBtn) {
            cancelBtn.remove();
        }
    }

    deleteMessage(messageId) {
        if (!confirm('Are you sure you want to delete this message?')) {
            return;
        }

        try {
            const messages = JSON.parse(localStorage.getItem('codehub_messages') || '[]');
            const messageIndex = messages.findIndex(m => m.id === messageId && m.userId === this.currentUser.id);
            
            if (messageIndex !== -1) {
                messages.splice(messageIndex, 1);
                localStorage.setItem('codehub_messages', JSON.stringify(messages));
                
                // Add activity
                this.addActivity('Deleted a message', 'message');
                
                // Show success message
                this.showToast('Message deleted successfully', 'success');
                
                // Reload messages
                this.loadChatMessages();
                this.loadDashboardData();
                this.loadProfileData();
            }
        } catch (error) {
            console.error('Error deleting message:', error);
            this.showToast('Error deleting message', 'error');
        }
    }

    loadProjects() {
        const container = document.getElementById('projectsList');
        container.innerHTML = '';

        const projects = JSON.parse(localStorage.getItem('codehub_projects') || '[]');
        const userProjects = projects.filter(p => p.userId === this.currentUser.id);

        if (userProjects.length === 0) {
            container.innerHTML = `
                <div class="text-center">
                    <p>No projects yet. Create your first project!</p>
                    <button class="btn btn-primary mt-2" onclick="app.showProjectModal()">
                        <i class="fas fa-plus"></i> Add Project
                    </button>
                </div>
            `;
            return;
        }

        userProjects.forEach(project => {
            const projectCard = this.createProjectCard(project);
            container.appendChild(projectCard);
        });
    }

    createProjectCard(project) {
        const projectCard = document.createElement('div');
        projectCard.className = 'project-card';
        
        const difficultyClass = `project-difficulty ${project.difficulty}`;
        const techTags = project.techStack ? project.techStack.map(tech => 
            `<span class="tech-tag">${tech}</span>`
        ).join('') : '';

        projectCard.innerHTML = `
            <div class="project-image">
                <i class="fas fa-code"></i>
            </div>
            <div class="project-content">
                <h3 class="project-title">${project.title}</h3>
                <p class="project-description">${project.description}</p>
                <div class="project-tech">
                    ${techTags}
                </div>
                <div class="project-meta">
                    <span class="${difficultyClass}">
                        ${project.difficulty || 'beginner'}
                    </span>
                    <div class="project-actions">
                        ${project.githubUrl ? `
                            <a href="${project.githubUrl}" target="_blank" class="btn btn-small btn-outline">
                                <i class="fab fa-github"></i>
                            </a>
                        ` : ''}
                        ${project.liveUrl ? `
                            <a href="${project.liveUrl}" target="_blank" class="btn btn-small btn-primary">
                                <i class="fas fa-external-link-alt"></i>
                            </a>
                        ` : ''}
                        <button class="btn btn-small btn-outline edit-project" data-id="${project.id}">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-small btn-danger delete-project" data-id="${project.id}">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;

        // Add event listeners
        const editBtn = projectCard.querySelector('.edit-project');
        const deleteBtn = projectCard.querySelector('.delete-project');
        
        editBtn.addEventListener('click', () => {
            this.editProject(project.id);
        });
        
        deleteBtn.addEventListener('click', () => {
            this.deleteProject(project.id);
        });

        return projectCard;
    }

    showProjectModal(project = null) {
        const modal = document.getElementById('projectModal');
        const title = document.getElementById('modalTitle');
        const form = document.getElementById('projectForm');
        
        // Reset form and editing state
        form.reset();
        this.editingProjectId = null;
        
        if (project) {
            // Edit mode
            this.editingProjectId = project.id;
            title.textContent = 'Edit Project';
            document.getElementById('saveProject').textContent = 'Update Project';
            
            // Fill form with project data
            document.getElementById('projectTitle').value = project.title;
            document.getElementById('projectDescription').value = project.description;
            document.getElementById('projectTech').value = project.techStack ? project.techStack.join(', ') : '';
            document.getElementById('projectDifficulty').value = project.difficulty || 'beginner';
            document.getElementById('projectGithub').value = project.githubUrl || '';
            document.getElementById('projectLive').value = project.liveUrl || '';
        } else {
            // Add mode
            title.textContent = 'Add New Project';
            document.getElementById('saveProject').textContent = 'Save Project';
        }
        
        modal.classList.add('active');
    }

    hideModal(modalId) {
        document.getElementById(modalId).classList.remove('active');
    }

    saveProject() {
        if (!this.currentUser) return;

        const project = {
            id: this.editingProjectId || Date.now(),
            userId: this.currentUser.id,
            title: document.getElementById('projectTitle').value,
            description: document.getElementById('projectDescription').value,
            techStack: document.getElementById('projectTech').value
                .split(',')
                .map(t => t.trim())
                .filter(t => t),
            difficulty: document.getElementById('projectDifficulty').value,
            githubUrl: document.getElementById('projectGithub').value || null,
            liveUrl: document.getElementById('projectLive').value || null,
            createdAt: this.editingProjectId ? 
                JSON.parse(localStorage.getItem('codehub_projects') || '[]')
                    .find(p => p.id === this.editingProjectId)?.createdAt || new Date().toISOString() 
                : new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };

        // Validation
        if (!project.title || !project.description) {
            this.showToast('Please fill in all required fields', 'error');
            return;
        }

        try {
            // Get existing projects
            const projects = JSON.parse(localStorage.getItem('codehub_projects') || '[]');
            
            if (this.editingProjectId) {
                // Update existing project
                const projectIndex = projects.findIndex(p => p.id === this.editingProjectId);
                if (projectIndex !== -1) {
                    projects[projectIndex] = project;
                    this.showToast('Project updated successfully!', 'success');
                }
            } else {
                // Add new project
                projects.push(project);
                this.showToast('Project saved successfully!', 'success');
                
                // Update user contributions for new projects only
                this.currentUser.contributions = (this.currentUser.contributions || 0) + 1;
                localStorage.setItem('codehub_user', JSON.stringify(this.currentUser));
                
                // Update users list
                const users = JSON.parse(localStorage.getItem('codehub_users') || '[]');
                const userIndex = users.findIndex(u => u.id === this.currentUser.id);
                if (userIndex !== -1) {
                    users[userIndex].contributions = this.currentUser.contributions;
                    localStorage.setItem('codehub_users', JSON.stringify(users));
                }
            }

            // Save updated projects
            localStorage.setItem('codehub_projects', JSON.stringify(projects));

            // Add activity
            this.addActivity(
                this.editingProjectId ? `Updated project: ${project.title}` : `Added project: ${project.title}`, 
                'project'
            );

            // Hide modal and reload projects
            this.hideModal('projectModal');
            this.loadProjects();
            this.loadDashboardData();
            this.loadProfileData();

        } catch (error) {
            console.error('Error saving project:', error);
            this.showToast('Error saving project', 'error');
        }
    }

    editProject(projectId) {
        try {
            const projects = JSON.parse(localStorage.getItem('codehub_projects') || '[]');
            const project = projects.find(p => p.id === projectId && p.userId === this.currentUser.id);
            
            if (project) {
                this.showProjectModal(project);
            } else {
                this.showToast('Project not found', 'error');
            }
        } catch (error) {
            console.error('Error loading project for editing:', error);
            this.showToast('Error loading project', 'error');
        }
    }

    deleteProject(projectId) {
        if (!confirm('Are you sure you want to delete this project? This action cannot be undone.')) {
            return;
        }

        try {
            const projects = JSON.parse(localStorage.getItem('codehub_projects') || '[]');
            const projectIndex = projects.findIndex(p => p.id === projectId && p.userId === this.currentUser.id);
            
            if (projectIndex !== -1) {
                const deletedProject = projects[projectIndex];
                projects.splice(projectIndex, 1);
                localStorage.setItem('codehub_projects', JSON.stringify(projects));
                
                // Add activity
                this.addActivity(`Deleted project: ${deletedProject.title}`, 'project');
                
                // Show success message
                this.showToast('Project deleted successfully', 'success');
                
                // Reload data
                this.loadProjects();
                this.loadDashboardData();
                this.loadProfileData();
            } else {
                this.showToast('Project not found', 'error');
            }
        } catch (error) {
            console.error('Error deleting project:', error);
            this.showToast('Error deleting project', 'error');
        }
    }

    loadProfileData() {
        if (!this.currentUser) return;

        document.getElementById('profileUsername').textContent = this.currentUser.username;
        document.getElementById('profileEmail').textContent = this.currentUser.email;
        
        // Load stats
        const projects = JSON.parse(localStorage.getItem('codehub_projects') || '[]');
        const messages = JSON.parse(localStorage.getItem('codehub_messages') || '[]');
        const userProjects = projects.filter(p => p.userId === this.currentUser.id);
        const userMessages = messages.filter(m => m.userId === this.currentUser.id);

        document.getElementById('profileProjectCount').textContent = userProjects.length;
        document.getElementById('profileMessageCount').textContent = userMessages.length;
        document.getElementById('profileSolvedCount').textContent = this.currentUser.solvedProblems || 0;

        // Load skills
        this.loadSkills();

        // Load timeline
        this.loadTimeline();
    }

    loadSkills() {
        const container = document.getElementById('skillsTags');
        const skills = this.currentUser.skills || [];
        
        if (skills.length === 0) {
            container.innerHTML = '<p>No skills added yet.</p>';
            return;
        }

        let html = '';
        skills.forEach(skill => {
            html += `
                <span class="skill-tag">
                    ${skill}
                    <button class="skill-remove" data-skill="${skill}">
                        <i class="fas fa-times"></i>
                    </button>
                </span>
            `;
        });
        container.innerHTML = html;

        // Add remove skill listeners
        container.querySelectorAll('.skill-remove').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const skill = e.target.closest('.skill-remove').dataset.skill;
                this.removeSkill(skill);
            });
        });
    }

    loadTimeline() {
        const container = document.getElementById('activityTimeline');
        container.innerHTML = '';

        const activities = JSON.parse(localStorage.getItem('codehub_activities') || '[]');
        const userActivities = activities
            .filter(a => a.userId === this.currentUser.id)
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
            .slice(0, 10);

        if (userActivities.length === 0) {
            container.innerHTML = '<p>No recent activity</p>';
            return;
        }

        userActivities.forEach(activity => {
            const item = document.createElement('div');
            item.className = 'timeline-item';
            item.innerHTML = `
                <div class="timeline-date">
                    ${new Date(activity.timestamp).toLocaleDateString()}
                </div>
                <div class="timeline-content">
                    ${activity.description}
                </div>
            `;
            container.appendChild(item);
        });
    }

    addSkill() {
        const input = document.getElementById('newSkill');
        const skill = input.value.trim();

        if (!skill) {
            this.showToast('Please enter a skill', 'error');
            return;
        }

        if (!this.currentUser.skills) {
            this.currentUser.skills = [];
        }

        if (this.currentUser.skills.includes(skill)) {
            this.showToast('Skill already exists', 'warning');
            input.value = '';
            return;
        }

        // Add skill
        this.currentUser.skills.push(skill);
        
        // Update localStorage
        localStorage.setItem('codehub_user', JSON.stringify(this.currentUser));

        // Update users list
        const users = JSON.parse(localStorage.getItem('codehub_users') || '[]');
        const userIndex = users.findIndex(u => u.id === this.currentUser.id);
        if (userIndex !== -1) {
            users[userIndex].skills = this.currentUser.skills;
            localStorage.setItem('codehub_users', JSON.stringify(users));
        }

        // Reload skills
        this.loadSkills();
        
        // Clear input
        input.value = '';
        
        this.showToast('Skill added successfully', 'success');
    }

    removeSkill(skill) {
        if (!confirm(`Remove skill "${skill}"?`)) {
            return;
        }

        // Remove skill
        this.currentUser.skills = this.currentUser.skills.filter(s => s !== skill);
        
        // Update localStorage
        localStorage.setItem('codehub_user', JSON.stringify(this.currentUser));

        // Update users list
        const users = JSON.parse(localStorage.getItem('codehub_users') || '[]');
        const userIndex = users.findIndex(u => u.id === this.currentUser.id);
        if (userIndex !== -1) {
            users[userIndex].skills = this.currentUser.skills;
            localStorage.setItem('codehub_users', JSON.stringify(users));
        }

        // Reload skills
        this.loadSkills();
        
        this.showToast('Skill removed', 'success');
    }

    addActivity(description, type) {
        if (!this.currentUser) return;

        const activity = {
            id: Date.now(),
            userId: this.currentUser.id,
            description,
            type,
            timestamp: new Date().toISOString()
        };

        try {
            const activities = JSON.parse(localStorage.getItem('codehub_activities') || '[]');
            activities.push(activity);
            localStorage.setItem('codehub_activities', JSON.stringify(activities));
            
            // Reload activity lists
            this.loadDashboardData();
            this.loadTimeline();
            
        } catch (error) {
            console.error('Error adding activity:', error);
        }
    }

    // Helper Methods
    showMessage(element, message, type) {
        if (!element) return;
        
        element.textContent = message;
        element.className = `message ${type}`;
        
        // Auto hide after 3 seconds
        setTimeout(() => {
            element.className = 'message';
            element.textContent = '';
        }, 3000);
    }

    showToast(message, type = 'info') {
        // Create toast element
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
                <span>${message}</span>
            </div>
            <button class="toast-close">&times;</button>
        `;

        // Add to page
        document.body.appendChild(toast);

        // Add animation
        setTimeout(() => toast.classList.add('show'), 10);

        // Auto remove after 3 seconds
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);

        // Close button
        toast.querySelector('.toast-close').addEventListener('click', () => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        });
    }

    togglePassword(passwordId, toggleId) {
        const passwordInput = document.getElementById(passwordId);
        const toggleIcon = document.getElementById(toggleId);
        
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            toggleIcon.className = 'fas fa-eye-slash';
        } else {
            passwordInput.type = 'password';
            toggleIcon.className = 'fas fa-eye';
        }
    }

    validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    getActivityIcon(type) {
        const icons = {
            'project': 'project-diagram',
            'message': 'comment',
            'login': 'sign-in-alt',
            'signup': 'user-plus',
            'problem': 'check-circle'
        };
        return icons[type] || 'circle';
    }
}

// Add toast styles
const toastStyles = document.createElement('style');
toastStyles.textContent = `
    .toast {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        padding: 1rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
        min-width: 300px;
        transform: translateX(100%);
        opacity: 0;
        transition: all 0.3s ease;
        z-index: 3000;
    }
    
    .toast.show {
        transform: translateX(0);
        opacity: 1;
    }
    
    .toast-success {
        border-left: 4px solid #00b894;
    }
    
    .toast-error {
        border-left: 4px solid #e17055;
    }
    
    .toast-info {
        border-left: 4px solid #6c5ce7;
    }
    
    .toast-content {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .toast-close {
        background: none;
        border: none;
        font-size: 1.2rem;
        cursor: pointer;
        color: #636e72;
    }
`;
document.head.appendChild(toastStyles);

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new CodeHubApp();
});
